<?php

declare(strict_types=1);

return [
    'jwt_secret' => 'please-change-me',
];
